# Galaxy AI V2
Galaxy-themed mobile AI assistant prototype.
Features: chat, local chat history, new chat, image selection UI, voice input where browser support exists, settings screen.
Real AI API is intentionally not included yet; connect it through a secure backend so the API key is not exposed in the app.
